<!DOCTYPE html>
<!-- (C) Tushar Shandilya -->
<html>
<head>
    <title>Display Records of the Event table</title>
    <link rel="stylesheet" href="../css/style.css" />
</head>

<body>
    <?php
    $servername = "localhost";
    $dbname = "CollegeClubsGroup8";
    $username = "root";
    $password = "";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "<p style='color:green'>Connection Was Successful</p>";
    } catch (PDOException $err) {
        echo "<p style='color:red'> Connection Failed: " . $err->getMessage() . "</p>\r\n";
    }

    try {
        $sql = "SELECT EventID, EventSubject, EventDate, EventTime, RegistrationFee, EventOrganizer, ERoomNumber, EFloor, EBuilding FROM Event WHERE EBuilding = '$_POST[building]'";

        $stmnt = $conn->prepare($sql);

        $stmnt->execute();

        $row = $stmnt->fetch();
        if ($row) {
            echo '<table>';
            echo '<tr> <th>EventID</th> <th>Event Subject</th> <th>Event Date</th> <th>Event Time</th> <th>Registration Fee</th> <th>Event Organizer</th> <th>Room Number</th> <th>Floor</th> <th>Building</th> </tr>';
            do {
                echo "<tr><td>$row[EventID]</td><td>$row[EventSubject]</td><td>$row[EventDate]</td><td>$row[EventTime]</td><td>$row[RegistrationFee]</td><td>$row[EventOrganizer]</td><td>$row[ERoomNumber]</td><td>$row[EFloor]</td><td>$row[EBuilding]</td></tr>";
            } while ($row = $stmnt->fetch());
            echo '</table>';
        } else {
            echo "<p> No Record Found!</p>";
        }
    } catch (PDOException $err) {
        echo "<p style='color:red'>Record Retrieval Failed: " . $err->getMessage() . "</p>\r\n";
    }
    // Close the connection
    unset($conn);

    echo "<a href='../index.html'>Back to the Homepage</a>";

    ?>
</body>

</html>
