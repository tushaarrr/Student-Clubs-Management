<!DOCTYPE html>
<!-- (C) Tushar Shandilya -->
<html>

<head>
    <title>Delete a record of a table</title>
    <link rel="stylesheet" href="../css/style.css" />
</head>

<body>

    <?php
    require 'config.php';

    /* Try MySQL server connection. Assuming you are running MySQL
    server with default setting (user 'root' with no password).
    If the connection was tried and it was successful, the code between braces after try is executed. If any error happened while running the code in try-block, 
    the code in catch-block is executed. */
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Sets the error mode of PHP engine to Exception to display all the errors
        echo "<p style='color:green'>Connection Was Successful</p>";
    } catch (PDOException $err) {
        echo "<p style='color:red'> Connection Failed: " . $err->getMessage() . "</p>\r\n";
    }

    try {
        // First, check if the record exists for deleting. If it does not exist, display a message; else, delete it.
        $sqlCheck = "SELECT EventID FROM $dbname.Event WHERE EventID = :eventid";
        $stmntCheck = $conn->prepare($sqlCheck);
        $stmntCheck->bindParam(':eventid', $_POST['eventId']); // :eventid is the variable used in $sqlCheck
        $stmntCheck->execute();

        if ($stmntCheck->rowCount() === 0) {
            echo "<p style='color:red'>Record not found. Cannot delete.</p>\r\n";
        } else {
            // Prepare and execute a DELETE query
            $sqlDelete = "DELETE FROM $dbname.Event WHERE EventID = :eventid";
            $stmntDelete = $conn->prepare($sqlDelete);
            $stmntDelete->bindParam(':eventid', $_POST['eventId']); // :eventid is the variable used in $sqlDelete
            $stmntDelete->execute();
            echo "<p style='color:green'>Record Deleted Successfully</p>";
        }
    } catch (PDOException $err) {
        echo "<p style='color:red'>Record Delete Failed: " . $err->getMessage() . "</p>\r\n";
    }

    // Close the connection
    unset($conn);

    echo "<a href='../index.html'>Back to the Homepage</a>";

    ?>

</body>

</html>
