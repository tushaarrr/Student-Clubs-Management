<!DOCTYPE html>
<!-- (C) Tushar Shandilya -->
<html>

<head>
    <title>Update a record of a table</title>
    <link rel="stylesheet" href="../css/style.css" />
</head>

<body>

    <?php
    require 'config.php';

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "<p style='color:green'>Connection Was Successful</p>";
    } catch (PDOException $err) {
        echo "<p style='color:red'> Connection Failed: " . $err->getMessage() . "</p>\r\n";
    }

    try {
        // First, check if the record exists for updating. If it does not exist, display a message; otherwise, update it.
        $sql = "SELECT EventID FROM $dbname.Event WHERE EventID = :eventid";
        $stmnt = $conn->prepare($sql);
        $stmnt->bindParam(':eventid', $_POST['eventId']);

        $stmnt->execute();

        if ($stmnt->rowCount() === 0) {
            echo "<p style='color:red'>Record not found. Cannot Update.</p>\r\n";
        } else {
            $sqlUpdate = "UPDATE $dbname.Event SET EventSubject = :newEventSubject WHERE EventID = :eventid";
            $stmntUpdate = $conn->prepare($sqlUpdate);
            $stmntUpdate->bindParam(':eventid', $_POST['eventId']);
            $stmntUpdate->bindParam(':newEventSubject', $_POST['newEventSubject']);

            $stmntUpdate->execute();
            echo "<p style='color:green'>Record Updated Successfully</p>";
        }
    } catch (PDOException $err) {
        echo "<p style='color:red'>Record Update Failed: " . $err->getMessage() . "</p>\r\n";
    }

    // Close the connection
    unset($conn);

    echo "<a href='../index.html'>Back to the Homepage</a>";

    ?>
</body>

</html>
