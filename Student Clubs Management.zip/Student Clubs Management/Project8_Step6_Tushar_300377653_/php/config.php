<?php

$servername = "localhost";   // means the database server is running on your own computer and not on a remote computer in a network or on the Internet.
$username = "root";          // root is the default administrator account name to access the DBMS
$password = "";                 // the password is empty by default, kepp it empty as well
$dbname = "CollegeClubsGroup8";        // The name of the database. Change it to the name of the database.
