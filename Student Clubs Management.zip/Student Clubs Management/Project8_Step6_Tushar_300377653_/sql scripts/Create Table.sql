-- 
-- Group 8 Adventure Seekers
-- Members: Tushar Shandilya, MySQL Expert
--          Samira Mehdizadeh, MS SQL Expert
-- --------------------------------------
CREATE DATABASE CollegeClubs;
USE CollegeClubs;

-- Student (Student ID, First Name, Last Name, Major, Email, Phone, Enrolment Date)
CREATE TABLE Student(
    StudentID INT,
    Firstname VARCHAR(20),
    Lastname VARCHAR(25),
    Major VARCHAR(20),
    Email VARCHAR(40),
    Phone VARCHAR(13),
    EnrolmentDate DATE,
    PRIMARY KEY (StudentID)
);

-- Alumni (Student ID, Alumni ID)
CREATE TABLE Alumni(
    StudentID INT,
    AlumniID INT,
    PRIMARY KEY (AlumniID)
);

-- Alumni_Work (Alumni ID, Company Name, Position, Start Date, End Date)
CREATE TABLE Alumni_Work(
    AlumniID INT,
    CompanyName VARCHAR(50),
    Position VARCHAR(50),
    StartDate DATE,
    EndDate DATE,
    PRIMARY KEY (AlumniID),
    FOREIGN KEY (AlumniID) REFERENCES Alumni (AlumniID)
);

-- Group (Group ID, Group Name, Group Head)
CREATE TABLE GroupC(
    GroupID INT,
    GroupName VARCHAR(50),
    GroupHead VARCHAR(50),
    PRIMARY KEY (GroupID)
);

-- Student_Joins_Group (Student ID, Group ID, Membership Start Date, Membership End Date)
CREATE TABLE Student_Joins_Group(
    StudentID INT,
    GroupID INT,
    MembershipStartDate DATE,
    MembershipEndDate DATE,
    PRIMARY KEY (StudentID, GroupID),
    FOREIGN KEY (StudentID) REFERENCES Student (StudentID),
    FOREIGN KEY (GroupID) REFERENCES GroupC (GroupID)
);

-- Club (Club ID, Group ID, Club Name, Club Head)
CREATE TABLE Club(
    ClubID INT,
    GroupID INT,
    ClubName VARCHAR(50),
    ClubHead VARCHAR(50),
    PRIMARY KEY (ClubID),
    FOREIGN KEY (GroupID) REFERENCES GroupC (GroupID)
);

-- Projects (Project ID, Group ID, Project Name, Project Start Date, Project End Date, Project Budget)
CREATE TABLE Projects(
    ProjectID INT,
    GroupID INT,
    ProjectName VARCHAR(50),
    ProjectStartDate DATE,
    ProjectEndDate DATE,
    ProjectBudget DECIMAL(10, 2),
    PRIMARY KEY (ProjectID),
    FOREIGN KEY (GroupID) REFERENCES GroupC (GroupID)
);

-- Funding (Funding ID, Payment Source, Payment Amount, Payment Date)
CREATE TABLE Funding(
    FundingID INT,
    PaymentSource VARCHAR(50),
    PaymentAmount DECIMAL(10, 2),
    PaymentDate DATE,
    PRIMARY KEY (FundingID)
);

-- Project_Receives_Funding (Project ID, Funding ID)
CREATE TABLE Project_Receives_Funding(
    ProjectID INT,
    FundingID INT,
    PRIMARY KEY (ProjectID, FundingID),
    FOREIGN KEY (ProjectID) REFERENCES Projects (ProjectID),
    FOREIGN KEY (FundingID) REFERENCES Funding (FundingID)
);

-- Event (Event ID, Event Subject, Event Date, Event Time, Registration Fee, Event Organizer, E-Room Number, E-Floor, E-Building)
CREATE TABLE Event(
    EventID INT,
    EventSubject VARCHAR(100),
    EventDate DATE,
    EventTime TIME,
    RegistrationFee DECIMAL(5, 2),
    EventOrganizer VARCHAR(50),
    ERoomNumber INT,
    EFloor INT,
    EBuilding VARCHAR(50),
    PRIMARY KEY (EventID)
);

-- Group_Organizes_Events (Group ID, Event ID)
CREATE TABLE Group_Organizes_Events(
    GroupID INT,
    EventID INT,
    PRIMARY KEY (GroupID, EventID),
    FOREIGN KEY (GroupID) REFERENCES GroupC (GroupID),
    FOREIGN KEY (EventID) REFERENCES Event (EventID)
);
