-- 
-- Group 8 Adventure Seekers
-- Members: Tushar Shandilya, MySQL Expert
--          Samira Mehdizadeh, MS SQL Expert
-- -------------------------------------- all query work on both server
use CollegeClubs;
INSERT INTO Student (StudentID, Firstname, Lastname, Major, Email, Phone, EnrolmentDate) 
VALUES 
(1, 'John', 'Doe', 'Computer Science', 'john.doe@email.com', '123-456-7890', '2023-09-01'),
(2, 'Jane', 'Smith', 'Biology', 'jane.smith@email.com', '098-765-4321', '2023-09-02');
INSERT INTO Student (StudentID, Firstname, Lastname, Major, Email, Phone, EnrolmentDate) VALUES
(3, 'Alice', 'Johnson', 'Physics', 'alice.johnson@email.com', '456-789-0123', '2023-09-03'),
(4, 'Bob', 'Williams', 'Engineering', 'bob.williams@email.com', '789-012-3456', '2023-09-04'),
(5, 'Carol', 'Davis', 'Mathematics', 'carol.davis@email.com', '012-345-6789', '2023-09-05');




-- Insert into Alumni table
INSERT INTO Alumni (StudentID, AlumniID) VALUES 
(1, 101),
(2, 102);
INSERT INTO Alumni (StudentID, AlumniID) VALUES
(3, 103),
(4, 104),
(5, 105);

-- Insert into Alumni_Work table
INSERT INTO Alumni_Work (AlumniID, Companyname, Position, EndDate, StartDate) VALUES 
(101, 'TechCorp', 'Software Engineer', '2025-08-01', '2023-10-01'),
(102, 'BioInc', 'Research Scientist', NULL, '2023-11-01');
INSERT INTO Alumni_Work (AlumniID, Companyname, Position, EndDate, StartDate) VALUES
(103, 'QuantumTech', 'Physicist', NULL, '2023-12-01'),
(104, 'BuildIt', 'Civil Engineer', '2026-05-01', '2024-01-01'),
(105, 'MathCo', 'Data Scientist', NULL, '2024-06-01');


INSERT INTO Alumni_Work (AlumniID, CompanyName, Position)
VALUES
(5, 'TechCorp', 'Engineer'),
(2, 'InnovateTech', 'Data Analyst'),
(3, 'PhotoWorks', 'Photographer');

-- Insert into Group table
INSERT INTO GroupC (GroupID, GroupName, GroupHead) VALUES 
(1, 'Tech Enthusiasts', 'John Doe'),
(2, 'Bio Club', 'Jane Smith');
INSERT INTO GroupC (GroupID, GroupName, GroupHead)
VALUES
(101, 'Chess Enthusiasts','Nandini'),
(102, 'Code Wizards', 'Tushar'),
(103, 'Shutterbugs', 'Samira');

INSERT INTO GroupC (GroupID, GroupName, GroupHead) VALUES
(3, 'Physics Society', 'Alice Johnson'),
(4, 'Engineering Club', 'Bob Williams'),
(5, 'Math Club', 'Carol Davis');

-- Insert into Student_Joins_Group table
INSERT INTO Student_Joins_Group (StudentID, GroupID, MembershipStartDate, MembershipEndDate) VALUES 
(1, 1, '2023-09-01', NULL), 
(2, 2, '2023-09-02', NULL);
INSERT INTO Student_Joins_Group (StudentID, GroupID)
VALUES
(1, 101),
(2, 102),
(3, 103),
(4, 104);
INSERT INTO Student_Joins_Group (StudentID, GroupID, MembershipStartDate, MembershipEndDate) VALUES
(3, 3, '2023-09-03', NULL),
(4, 4, '2023-09-04', NULL),
(5, 5, '2023-09-05', NULL);

-- Insert into Club table
INSERT INTO Club (ClubID, GroupID, ClubName, ClubHead) VALUES 
(201, 1, 'Tech Club', 'John Doe'),
(202, 2, 'Biology Club', 'Jane Smith');
INSERT INTO Club (ClubID, ClubName, ClubHead)
VALUES
(101, 'Chess Club', 'Alice'),
(102, 'Programming Club', 'Bob'),
(103, 'Photography Club', 'Charlie'),
(104, 'Art Club', 'Eve');
INSERT INTO Club (ClubID, GroupID, ClubName, ClubHead) VALUES
(203, 3, 'Quantum Club', 'Alice Johnson'),
(204, 4, 'Future Builders', 'Bob Williams'),
(205, 5, 'Logic Lovers', 'Carol Davis');


-- Insert into Projects table
INSERT INTO Projects (ProjectID, GroupID, ProjectName, ProjectStartDate, ProjectEndDate, ProjectBudget) VALUES 
(301, 1, 'Robotics Challenge', '2023-10-01', '2024-10-01', 15000.00),
(302, 2, 'Genetics Seminar', '2023-12-01', '2024-02-01', 5000.00);
INSERT INTO Projects (ProjectID, GroupID, ProjectName, ProjectStartDate, ProjectEndDate, ProjectBudget) VALUES
(303, 3, 'Particle Physics Study', '2023-11-01', '2024-11-01', 12000.00),
(304, 4, 'Sustainable Engineering', '2024-01-01', '2025-01-01', 20000.00),
(305, 5, 'Algorithms Research', '2024-02-01', '2025-02-01', 8000.00);


-- Insert into Funding table
INSERT INTO Funding (FundingID, PaymentSource, PaymentAmount, PaymentDate) VALUES 
(401, 'University Grant', 10000.00, '2023-08-15'),
(402, 'Private Donor', 6000.00, '2023-09-01');
INSERT INTO Funding (FundingID, PaymentSource, PaymentAmount, PaymentDate) VALUES
(403, 'Alumni Donations', 15000.00, '2023-10-01'),
(404, 'Corporate Sponsorship', 25000.00, '2023-11-01');


-- Insert into Project_Receives_Funding table
INSERT INTO Project_Receives_Funding (ProjectID, FundingID) VALUES 
(301, 401),
(302, 402);
INSERT INTO Project_Receives_Funding (ProjectID, FundingID) VALUES
(303, 403),
(304, 404);

-- Insert into Event table
INSERT INTO Event (EventID, EventSubject, EventDate, EventTime, RegistrationFee, EventOrganizer, ERoomNumber, EFloor, EBuilding) VALUES 
(501, 'AI Conference', '2024-05-15', '10:00:00', 20.00, 'Tech Enthusiasts', 101, 1, 'Science Bldg'),
(502, 'Sustainability Workshop', '2024-06-20', '09:30:00', 15.00, 'Bio Club', 202, 2, 'Enviro Hall');
INSERT INTO Event (EventID, EventSubject, EventDate, EventTime, RegistrationFee, EventOrganizer, ERoomNumber, EFloor, EBuilding) VALUES
(503, 'Quantum Computing Symposium', '2024-07-15', '09:00:00', 30.00, 'Physics Society', 301, 3, 'Tech Center'),
(504, 'Green Engineering Expo', '2024-08-20', '11:00:00', 25.00, 'Engineering Club', 402, 4, 'Innovation Hub');

-- Insert into Group_Organizes_Events table
INSERT INTO Group_Organizes_Events (GroupID, EventID) VALUES 
(1, 501),
(2, 502);
INSERT INTO Group_Organizes_Events (GroupID, EventID) VALUES
(3, 503),
(4, 504);
