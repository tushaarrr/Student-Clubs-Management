-- 
-- Group 8 Adventure Seekers
-- Members: Tushar Shandilya, MySQL Expert
--          Samira Mehdizadeh, MS SQL Expert
-- --------------------------------------
-- The DROP TABLE statements at the end
use CollegeClubs;
DROP TABLE Group_Organizes_Events;
DROP TABLE Project_Receives_Funding;
DROP TABLE Funding;
DROP TABLE Projects;
DROP TABLE Club;
DROP TABLE Student_Joins_Group;
DROP TABLE GroupC;
DROP TABLE Alumni_Work;
DROP TABLE Alumni;
DROP TABLE Student;