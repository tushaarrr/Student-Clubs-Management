-- 
-- Group 8 Adventure Seekers
-- Members: Tushar Shandilya, MySQL Expert
--          Samira Mehdizadeh, MS SQL Expert

-- in Query 11

-- this version of query doesnt work in MYsql Server but works in MS SQL SERVER
-- UPDATE Projects
-- SET ProjectBudget = (SELECT AVG(ProjectBudget) FROM Projects);


use CollegeClubs;





-- 1.)Retrieve details of students and the groups they have joined.

SELECT Student.*, GroupC.GroupName
FROM Student
INNER JOIN Student_Joins_Group ON Student.StudentID = Student_Joins_Group.StudentID
INNER JOIN GroupC ON Student_Joins_Group.GroupID = GroupC.GroupID;


-- 2.)Retrieve details of alumni and their work details, including those without work details.

SELECT Alumni.*, Alumni_Work.CompanyName, Alumni_Work.Position
FROM Alumni
LEFT JOIN Alumni_Work ON Alumni.AlumniID = Alumni_Work.AlumniID;


-- 3.)Update the phone number for a specific student.

UPDATE Student
SET Phone = '111-222-3333'
WHERE StudentID = 1;






-- 4.)Calculate the average registration fee for all events.

SELECT AVG(RegistrationFee) AS AverageRegistrationFee
FROM Event;


-- 5.)Find the minimum enrolment date among all students.

SELECT MIN(EnrolmentDate) AS MinEnrolmentDate
FROM Student;


-- 6.)Find the maximum project budget among all projects.

SELECT MAX(ProjectBudget) AS MaxProjectBudget
FROM Projects;


-- 7.)Count the number of students in each group.

SELECT GroupC.GroupName, COUNT(Student.StudentID) AS StudentCount
FROM GroupC
LEFT JOIN Student_Joins_Group ON GroupC.GroupID = Student_Joins_Group.GroupID
LEFT JOIN Student ON Student_Joins_Group.StudentID = Student.StudentID
GROUP BY GroupC.GroupName;


-- 8.)Find the alumni who have worked in companies with a position containing 'Engineer'.

SELECT *
FROM Alumni
WHERE AlumniID IN (SELECT AlumniID FROM Alumni_Work WHERE Position LIKE '%Engineer%');


-- 9.)Create a view to display student details along with the groups they have joined.

-- 1st step
CREATE VIEW Student_Group_Details AS
SELECT Student.*, GroupC.GroupName
FROM Student
INNER JOIN Student_Joins_Group ON Student.StudentID = Student_Joins_Group.StudentID
INNER JOIN GroupC ON Student_Joins_Group.GroupID = GroupC.GroupID;
-- 2nd step
SELECT * FROM Student_Group_Details;


-- 10.)Retrieve all possible combinations of students and events they organize.

SELECT Student.*, Event.*
FROM Student
CROSS JOIN Group_Organizes_Events
CROSS JOIN Event;


-- 11.)Update the project budget based on the average budget of all projects.

-- this version of query doesnt work in MYsql Server but works in MS SQL SERVER
-- UPDATE Projects
-- SET ProjectBudget = (SELECT AVG(ProjectBudget) FROM Projects);


UPDATE Projects
INNER JOIN (SELECT AVG(ProjectBudget) AS avgBudget FROM Projects) AS subquery
SET Projects.ProjectBudget = subquery.avgBudget;





-- 12.)Calculate the total payment amount for each payment source.

SELECT PaymentSource, SUM(PaymentAmount) AS TotalPaymentAmount
FROM Funding
GROUP BY PaymentSource;


-- 13.)Find the groups with more than two members.

SELECT GroupName
FROM GroupC
WHERE GroupID IN (SELECT GroupID FROM Student_Joins_Group GROUP BY GroupID HAVING COUNT(StudentID) > 2);


-- 14.)Retrieve details of students and the projects they are involved in.

SELECT Student.*, Projects.ProjectName
FROM Student
INNER JOIN Student_Joins_Group ON Student.StudentID = Student_Joins_Group.StudentID
INNER JOIN GroupC ON Student_Joins_Group.GroupID = GroupC.GroupID
INNER JOIN Projects ON GroupC.GroupID = Projects.GroupID;


-- 15.)Update the club head for a specific club.

UPDATE Club
SET ClubHead = 'New Club Head'
WHERE ClubID = 201;


-- 16.)Check if there are any projects organized by a specific group.

SELECT *
FROM GroupC
WHERE EXISTS (SELECT 1 FROM Projects WHERE GroupC.GroupID = Projects.GroupID);

-- 17.) Check if there are any students from the Computer Science.

SELECT *
FROM Student
WHERE Major = 'Computer Science';



-- 18.) Check if there are any projects that start in the year of 2023.

SELECT * 
FROM Projects
WHERE 'StartDate' BETWEEN '2022-09-01' AND '2023-12-30';


-- 19.)Combine the result of two statement of Club and Project and give the distinct value.

SELECT GroupID FROM Club
UNION
SELECT GroupID FROM Projects
ORDER BY GroupID;


--  20.)Show all Alumnis that their AlumniID starts with the code "1": 

SELECT * FROM Alumni_Work
WHERE AlumniID LIKE '1%';